# AI Integration Guide

## Adding Real AI to Your Project

This guide shows you how to integrate real AI APIs into your AI Study Assistant.

## 🔹 Option 1: OpenAI API (ChatGPT)

### Step 1: Get API Key
1. Go to https://platform.openai.com
2. Sign up/login
3. Go to API Keys section
4. Create new API key
5. Copy and save it securely

### Step 2: Install Library
```bash
pip install openai
```

### Step 3: Basic Integration
```python
import openai

# Set your API key
openai.api_key = "your-api-key-here"

def get_ai_response(prompt):
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful study assistant."},
            {"role": "user", "content": prompt}
        ]
    )
    return response.choices[0].message.content

# Test it
print(get_ai_response("What's the best study technique?"))
```

### Step 4: Add to Your Project
Replace the rule-based responses with AI-generated ones:

```python
def chat_with_ai(self):
    user_input = input("You: ").strip()

    # Get AI response
    ai_response = get_ai_response(user_input)

    print(f"AI: {ai_response}")
```

### Pricing
- **GPT-3.5**: ~$0.002 per 1K tokens (very cheap)
- **GPT-4**: ~$0.03 per 1K tokens (more expensive)
- **Free tier**: $5 credit for first 3 months

## 🔹 Option 2: Google Gemini API

### Step 1: Get API Key
1. Go to https://makersuite.google.com
2. Sign up/login with Google
3. Get API key
4. Copy and save it

### Step 2: Install Library
```bash
pip install google-generativeai
```

### Step 3: Basic Integration
```python
import google.generativeai as genai

# Configure API key
genai.configure(api_key="your-api-key-here")

# Initialize model
model = genai.GenerativeModel('gemini-pro')

def get_ai_response(prompt):
    response = model.generate_content(prompt)
    return response.text

# Test it
print(get_ai_response("Give me 5 study tips"))
```

### Step 4: Advanced Usage
```python
# With conversation history
chat = model.start_chat(history=[])

def chat_with_ai(message):
    response = chat.send_message(message)
    return response.text
```

### Pricing
- **Free**: 60 requests per minute
- **Paid**: $0.0005 per 1K characters

## 🔹 Option 3: Hugging Face (Free Alternative)

### Step 1: Get API Token
1. Go to https://huggingface.co
2. Sign up/login
3. Go to Settings → Access Tokens
4. Create new token

### Step 2: Install Library
```bash
pip install huggingface_hub
```

### Step 3: Basic Integration
```python
from huggingface_hub import InferenceClient

client = InferenceClient(token="your-token-here")

def get_ai_response(prompt):
    response = client.text_generation(
        prompt,
        model="mistralai/Mistral-7B-Instruct-v0.1",
        max_new_tokens=500
    )
    return response

# Test it
print(get_ai_response("Explain Python functions"))
```

### Pricing
- **Free tier**: Available with rate limits
- **Pro**: $9/month for higher limits

## 🔹 Complete Integration Example

Here's how to modify your AI Study Assistant:

```python
import openai
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class AIStudyAssistantWithAPI:
    def __init__(self):
        self.api_key = os.getenv("OPENAI_API_KEY")
        openai.api_key = self.api_key

        # AI system message
        self.system_message = {
            "role": "system", 
            "content": """You are an AI Study Assistant. 
            Help students with study planning, tips, and motivation.
            Be encouraging, practical, and specific.
            Keep responses concise but helpful."""
        }

    def get_study_tips_ai(self, topic):
        """Get AI-powered study tips"""
        prompt = f"Give me 5 specific study tips for {topic}"

        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                self.system_message,
                {"role": "user", "content": prompt}
            ],
            max_tokens=500,
            temperature=0.7
        )

        return response.choices[0].message.content

    def generate_schedule_ai(self, subjects, hours):
        """AI-generated study schedule"""
        prompt = f"""Create a detailed study schedule for:
        Subjects: {', '.join(subjects)}
        Available hours: {hours} per day

        Include specific time slots, breaks, and study techniques."""

        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                self.system_message,
                {"role": "user", "content": prompt}
            ],
            max_tokens=1000,
            temperature=0.7
        )

        return response.choices[0].message.content

    def chat_ai(self, message):
        """General AI chat"""
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                self.system_message,
                {"role": "user", "content": message}
            ],
            max_tokens=300,
            temperature=0.8
        )

        return response.choices[0].message.content

# Usage
assistant = AIStudyAssistantWithAPI()
print(assistant.get_study_tips_ai("Python programming"))
```

## 🔹 Best Practices

### 1. Environment Variables
Never hardcode API keys! Use environment variables:

```python
# .env file
OPENAI_API_KEY=your-key-here
GEMINI_API_KEY=your-key-here

# In code
from dotenv import load_dotenv
load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")
```

### 2. Error Handling
```python
try:
    response = openai.ChatCompletion.create(...)
except openai.error.RateLimitError:
    print("Rate limit exceeded. Please wait.")
except openai.error.AuthenticationError:
    print("Invalid API key.")
except Exception as e:
    print(f"Error: {e}")
```

### 3. Cost Management
```python
# Track token usage
response = openai.ChatCompletion.create(...)
usage = response.usage
print(f"Tokens used: {usage.total_tokens}")
print(f"Cost: ${usage.total_tokens * 0.002 / 1000:.4f}")
```

### 4. Caching
```python
# Cache common responses to save costs
cache = {}

def get_cached_response(prompt):
    if prompt in cache:
        return cache[prompt]

    response = get_ai_response(prompt)
    cache[prompt] = response
    return response
```

### 5. Rate Limiting
```python
import time
from datetime import datetime, timedelta

class RateLimiter:
    def __init__(self, calls_per_minute=60):
        self.calls = []
        self.limit = calls_per_minute

    def wait_if_needed(self):
        now = datetime.now()
        self.calls = [c for c in self.calls if now - c < timedelta(minutes=1)]

        if len(self.calls) >= self.limit:
            sleep_time = 60 - (now - self.calls[0]).seconds
            time.sleep(sleep_time)

        self.calls.append(now)

# Usage
limiter = RateLimiter()
limiter.wait_if_needed()
response = get_ai_response(prompt)
```

## 🔹 Hybrid Approach (Recommended)

Combine rule-based and AI responses:

```python
def get_study_tips(self, topic):
    # Use AI for complex topics
    complex_topics = ['advanced', 'optimization', 'strategy']

    if any(t in topic.lower() for t in complex_topics):
        return self.get_ai_tips(topic)
    else:
        # Use rule-based for simple topics (faster, free)
        return self.study_tips.get(topic, ["General tip here"])
```

## 🔹 Testing Your Integration

```python
def test_ai_integration():
    print("Testing AI Integration...")

    # Test 1: Basic response
    response = get_ai_response("Hello")
    assert len(response) > 0
    print("✓ Basic test passed")

    # Test 2: Study tips
    tips = get_ai_response("Give me 3 study tips")
    assert "tip" in tips.lower() or "study" in tips.lower()
    print("✓ Study tips test passed")

    # Test 3: Error handling
    try:
        bad_response = get_ai_response("")  # Empty prompt
        print("✓ Error handling test passed")
    except:
        print("✓ Error handling test passed")

    print("\nAll tests passed! ✅")

test_ai_integration()
```

## 🔹 Deployment Considerations

### For Local Development:
- Use `.env` file for API keys
- Implement rate limiting
- Add error handling
- Log API usage

### For Production:
- Use environment variables from hosting platform
- Implement proper authentication
- Add usage monitoring
- Set up cost alerts
- Use caching aggressively

## 🔹 Cost Estimation

**Example**: 100 users, 10 queries/day each

```
100 users × 10 queries × 500 tokens = 500,000 tokens/day
500,000 tokens × $0.002/1K = $1/day
Monthly cost: ~$30
```

**Tips to Reduce Costs**:
1. Use GPT-3.5 instead of GPT-4
2. Cache common responses
3. Use rule-based for simple queries
4. Set token limits
5. Monitor usage closely

## 🔹 Resources

- [OpenAI API Docs](https://platform.openai.com/docs)
- [Google Gemini Docs](https://ai.google.dev/docs)
- [Hugging Face Docs](https://huggingface.co/docs)
- [LangChain](https://python.langchain.com/) - Advanced AI app framework

---

*Start with free tiers, scale as you grow!*
