"""
AI-Powered Study Assistant
A simple AI-powered application that helps students with study planning and productivity.

Features:
- Generate study schedules
- Create to-do lists
- Provide study tips
- Track study progress
- AI-powered recommendations

Note: This is a rule-based AI assistant (no API keys needed)
For real AI, integrate with OpenAI, Gemini, or other AI APIs
"""

import datetime
import json
import os

class AIStudyAssistant:
    """AI-powered study assistant for students"""

    def __init__(self):
        self.user_name = ""
        self.study_goals = []
        self.tasks = []
        self.study_history = []

        # AI knowledge base (rule-based responses)
        self.study_tips = {
            'time_management': [
                "Use the Pomodoro Technique: 25 min study + 5 min break",
                "Study during your peak energy hours (morning/evening)",
                "Break large tasks into smaller, manageable chunks",
                "Use a calendar to block study time",
                "Avoid multitasking - focus on one subject at a time"
            ],
            'memory': [
                "Use active recall: test yourself instead of re-reading",
                "Apply spaced repetition: review at increasing intervals",
                "Create mind maps and visual diagrams",
                "Teach concepts to someone else",
                "Use mnemonics and memory palaces"
            ],
            'focus': [
                "Eliminate distractions (phone, social media)",
                "Create a dedicated study space",
                "Use website blockers during study time",
                "Practice mindfulness and meditation",
                "Take regular breaks to maintain focus"
            ],
            'exam_prep': [
                "Start studying at least 2 weeks before exams",
                "Practice with past papers and sample questions",
                "Focus on understanding, not memorization",
                "Create summary notes for quick revision",
                "Get adequate sleep before exam day"
            ],
            'motivation': [
                "Set clear, achievable goals",
                "Reward yourself after completing tasks",
                "Study with a group or accountability partner",
                "Visualize your success and long-term goals",
                "Remember why you started - keep your purpose in mind"
            ]
        }

        self.subject_recommendations = {
            'python': [
                "Practice coding daily on HackerRank or LeetCode",
                "Build small projects to apply concepts",
                "Read Python documentation and PEP 8 style guide",
                "Watch tutorial videos on YouTube (Corey Schafer, Tech With Tim)",
                "Join Python communities on Reddit or Discord"
            ],
            'data_structures': [
                "Visualize data structures using online tools",
                "Implement each structure from scratch",
                "Solve problems on platforms like GeeksforGeeks",
                "Understand time and space complexity",
                "Practice array, linked list, tree problems daily"
            ],
            'algorithms': [
                "Start with sorting and searching algorithms",
                "Understand Big O notation thoroughly",
                "Practice on coding platforms daily",
                "Watch algorithm visualization videos",
                "Solve problems by difficulty level (easy → hard)"
            ],
            'mathematics': [
                "Practice problems daily, don't just read theory",
                "Understand derivations, not just formulas",
                "Use Khan Academy for concept clarity",
                "Solve previous year question papers",
                "Create formula sheets for quick revision"
            ],
            'general': [
                "Attend all lectures and take notes",
                "Review notes within 24 hours of class",
                "Form study groups with classmates",
                "Ask questions when confused",
                "Balance study with rest and recreation"
            ]
        }

    def greet_user(self):
        """Welcome the user"""
        print("=" * 70)
        print("       🤖 AI STUDY ASSISTANT - Your Smart Study Companion")
        print("=" * 70)
        print("\nWelcome! I'm your AI-powered study assistant.")
        print("I can help you with study planning, tips, and productivity!")
        print("-" * 70)

        if not self.user_name:
            self.user_name = input("\nWhat's your name? ").strip()
            print(f"\nNice to meet you, {self.user_name}! Let's get started! 🚀")

    def display_menu(self):
        """Display main menu"""
        print("\n" + "=" * 70)
        print(f"  Hello, {self.user_name}! What would you like to do today?")
        print("=" * 70)

        menu_options = {
            1: "📅 Generate Study Schedule",
            2: "✅ Create To-Do List",
            3: "💡 Get Study Tips (AI-Powered)",
            4: "📚 Subject-Specific Recommendations",
            5: "🎯 Set Study Goals",
            6: "📊 View Progress & History",
            7: "🧠 AI Study Quiz",
            8: "💬 Chat with AI Assistant",
            9: "📝 Save Session & Exit"
        }

        for key, value in menu_options.items():
            print(f"  {key}. {value}")

        print("=" * 70)

    def generate_study_schedule(self):
        """Generate a personalized study schedule"""
        print("\n" + "=" * 70)
        print("  📅 AI-POWERED STUDY SCHEDULE GENERATOR")
        print("=" * 70)

        # Get user preferences
        print("\nLet me create your optimal study schedule!")

        try:
            study_hours = int(input("\nHow many hours can you study daily? (1-12): "))
            study_hours = max(1, min(12, study_hours))  # Clamp between 1-12

            subjects = input("Enter subjects to study (comma-separated): ").strip()
            subject_list = [s.strip() for s in subjects.split(',')]

            preferred_time = input("Preferred study time (morning/afternoon/evening/night): ").strip().lower()

            # AI-powered schedule generation
            print("\n⏰ Generating your personalized schedule...")

            schedule = self._create_schedule(study_hours, subject_list, preferred_time)

            print("\n" + "=" * 70)
            print("  YOUR AI-GENERATED STUDY SCHEDULE")
            print("=" * 70)
            print(schedule)
            print("=" * 70)

            # Save to history
            self.study_history.append({
                'type': 'schedule',
                'timestamp': datetime.datetime.now().isoformat(),
                'schedule': schedule
            })

            save = input("\nSave this schedule? (yes/no): ").strip().lower()
            if save == 'yes':
                self._save_schedule(schedule)
                print("✓ Schedule saved successfully!")

        except ValueError:
            print("Invalid input! Please enter numbers for hours.")

    def _create_schedule(self, hours, subjects, time_pref):
        """Create study schedule based on AI rules"""

        # Time slot recommendations
        time_slots = {
            'morning': '6:00 AM - 12:00 PM',
            'afternoon': '12:00 PM - 5:00 PM',
            'evening': '5:00 PM - 9:00 PM',
            'night': '9:00 PM - 12:00 AM'
        }

        schedule = f"""
📋 Personalized Study Schedule for {self.user_name}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⏰ Preferred Time: {time_pref.title()} ({time_slots.get(time_pref, 'Flexible')})
📚 Subjects: {', '.join(subjects)}
⌛ Daily Study Hours: {hours}

📅 DAILY ROUTINE:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""

        # Generate schedule based on hours
        if hours >= 6:
            schedule += """
🌅 MORNING SESSION (3 hours)
   • 6:00 - 7:30 AM  → {subject1} (Deep work - difficult topics)
   • 7:30 - 8:00 AM  → Breakfast break
   • 8:00 - 9:30 AM  → {subject2} (Practice problems)

☀️ AFTERNOON SESSION (2 hours)
   • 2:00 - 3:30 PM  → {subject3} (Theory & notes)
   • 3:30 - 4:00 PM  → Short break

🌆 EVENING SESSION (2+ hours)
   • 6:00 - 7:30 PM  → Revision & practice
   • 7:30 - 8:00 PM  → Plan next day
   • 8:00 - 9:00 PM  → Light reading/flashcards

💡 AI TIPS:
   ✓ Take 5-min breaks every 25-30 minutes (Pomodoro)
   ✓ Stay hydrated and snack healthy
   ✓ Review what you studied before sleeping
   ✓ Get 7-8 hours of sleep for memory consolidation
""".format(
                subject1=subjects[0] if len(subjects) > 0 else "Subject 1",
                subject2=subjects[1] if len(subjects) > 1 else "Subject 2",
                subject3=subjects[2] if len(subjects) > 2 else "Subject 3"
            )
        elif hours >= 4:
            schedule += """
🌅 MORNING SESSION (2 hours)
   • 7:00 - 9:00 AM  → {subject1} (Fresh mind - difficult topics)

☀️ EVENING SESSION (2+ hours)
   • 6:00 - 8:00 PM  → {subject2} (Practice & revision)
   • 8:00 - 8:30 PM  → Quick review

💡 AI TIPS:
   ✓ Morning study is best for difficult subjects
   ✓ Evening review strengthens memory
   ✓ Take breaks every hour
""".format(
                subject1=subjects[0] if len(subjects) > 0 else "Subject 1",
                subject2=subjects[1] if len(subjects) > 1 else "Subject 2"
            )
        else:
            schedule += """
🌆 POWER SESSION ({hours} hours)
   • 6:00 - {end_time}:00 PM  → Focused study on {subject1}

   • Take 5-min break every 25 minutes

💡 AI TIPS:
   ✓ Quality over quantity - stay focused
   ✓ Eliminate all distractions
   ✓ Active recall is key
""".format(
                hours=hours,
                end_time=6 + hours,
                subject1=subjects[0] if len(subjects) > 0 else "Your subject"
            )

        schedule += """
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎯 Remember: Consistency is more important than duration!
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""

        return schedule

    def create_todo_list(self):
        """Create AI-powered to-do list"""
        print("\n" + "=" * 70)
        print("  ✅ AI-POWERED TO-DO LIST CREATOR")
        print("=" * 70)

        print("\nAdd your tasks (type 'done' when finished):")
        print("-" * 70)

        tasks = []
        task_num = 1

        while True:
            task = input(f"\nTask {task_num}: ").strip()
            if task.lower() == 'done':
                break

            # AI priority suggestion
            priority = self._suggest_priority(task)
            estimated_time = input(f"Estimated time (in minutes): ").strip()

            try:
                time_mins = int(estimated_time)
            except:
                time_mins = 30

            tasks.append({
                'id': task_num,
                'task': task,
                'priority': priority,
                'time': time_mins,
                'completed': False
            })
            task_num += 1

        # Display organized to-do list
        print("\n" + "=" * 70)
        print("  YOUR AI-ORGANIZED TO-DO LIST")
        print("=" * 70)

        # Sort by priority
        priority_order = {'High': 0, 'Medium': 1, 'Low': 2}
        tasks_sorted = sorted(tasks, key=lambda x: priority_order[x['priority']])

        for i, task in enumerate(tasks_sorted, 1):
            priority_icon = {'High': '🔴', 'Medium': '🟡', 'Low': '🟢'}
            print(f"\n{i}. {priority_icon[task['priority']]} [{task['priority']}] {task['task']}")
            print(f"   ⏱️  Estimated: {task['time']} minutes")

        total_time = sum(t['time'] for t in tasks)
        print(f"\n{'='*70}")
        print(f"  Total Estimated Time: {total_time} minutes ({total_time/60:.1f} hours)")
        print(f"  AI Tip: Start with High priority tasks first!")
        print(f"{'='*70}")

        self.tasks = tasks_sorted
        self.study_history.append({
            'type': 'todo_list',
            'timestamp': datetime.datetime.now().isoformat(),
            'tasks': tasks_sorted
        })

    def _suggest_priority(self, task):
        """AI-based priority suggestion"""
        task_lower = task.lower()

        high_keywords = ['exam', 'test', 'deadline', 'urgent', 'important', 'assignment', 'project']
        medium_keywords = ['study', 'read', 'practice', 'review', 'notes', 'homework']

        if any(keyword in task_lower for keyword in high_keywords):
            return 'High'
        elif any(keyword in task_lower for keyword in medium_keywords):
            return 'Medium'
        else:
            return 'Low'

    def get_study_tips(self):
        """Get AI-powered study tips"""
        print("\n" + "=" * 70)
        print("  💡 AI-POWERED STUDY TIPS")
        print("=" * 70)

        print("\nWhat area do you need help with?")

        categories = {
            1: "⏰ Time Management",
            2: "🧠 Memory & Retention",
            3: "🎯 Focus & Concentration",
            4: "📝 Exam Preparation",
            5: "💪 Motivation",
            6: "All Categories"
        }

        for key, value in categories.items():
            print(f"  {key}. {value}")

        try:
            choice = int(input("\nEnter your choice (1-6): "))

            print("\n" + "=" * 70)
            print("  AI-GENERATED STUDY TIPS")
            print("=" * 70)

            if choice == 6:
                # Show all tips
                for category, tips in self.study_tips.items():
                    print(f"\n📌 {category.upper().replace('_', ' ')}:")
                    print("-" * 70)
                    for tip in tips:
                        print(f"  ✓ {tip}")
            else:
                category_map = {
                    1: 'time_management',
                    2: 'memory',
                    3: 'focus',
                    4: 'exam_prep',
                    5: 'motivation'
                }

                category = category_map.get(choice, 'time_management')
                tips = self.study_tips.get(category, [])

                print(f"\n📌 {category.upper().replace('_', ' ')} TIPS:")
                print("-" * 70)
                for tip in tips:
                    print(f"  ✓ {tip}")

            print("\n" + "=" * 70)
            print("  💡 AI INSIGHT: The best tip is the one you actually use!")
            print("  Start with ONE tip and build the habit before adding more.")
            print("=" * 70)

        except ValueError:
            print("Invalid choice! Please enter a number.")

    def get_subject_recommendations(self):
        """Get subject-specific AI recommendations"""
        print("\n" + "=" * 70)
        print("  📚 SUBJECT-SPECIFIC AI RECOMMENDATIONS")
        print("=" * 70)

        print("\nWhich subject do you want recommendations for?")

        subjects = {
            1: "🐍 Python Programming",
            2: "📊 Data Structures",
            3: "⚙️ Algorithms",
            4: "📐 Mathematics",
            5: "📖 General Study Tips"
        }

        for key, value in subjects.items():
            print(f"  {key}. {value}")

        try:
            choice = int(input("\nEnter your choice (1-5): "))

            subject_map = {
                1: 'python',
                2: 'data_structures',
                3: 'algorithms',
                4: 'mathematics',
                5: 'general'
            }

            subject = subject_map.get(choice, 'general')
            recommendations = self.subject_recommendations.get(subject, [])

            print("\n" + "=" * 70)
            print(f"  AI RECOMMENDATIONS FOR {subject.upper().replace('_', ' ')}")
            print("=" * 70)

            for i, rec in enumerate(recommendations, 1):
                print(f"\n{i}. {rec}")

            print("\n" + "=" * 70)
            print("  💡 AI TIP: Consistency beats intensity!")
            print("  Practice a little every day rather than cramming.")
            print("=" * 70)

        except ValueError:
            print("Invalid choice! Please enter a number.")

    def set_study_goals(self):
        """Set and track study goals"""
        print("\n" + "=" * 70)
        print("  🎯 SET YOUR STUDY GOALS")
        print("=" * 70)

        print("\nSMART Goals Framework:")
        print("  S - Specific")
        print("  M - Measurable")
        print("  A - Achievable")
        print("  R - Relevant")
        print("  T - Time-bound")
        print("-" * 70)

        goals = []

        print("\nEnter your study goals (type 'done' when finished):")

        goal_num = 1
        while True:
            goal = input(f"\nGoal {goal_num}: ").strip()
            if goal.lower() == 'done':
                break

            deadline = input("Deadline (e.g., '2 weeks', '1 month'): ").strip()

            goals.append({
                'id': goal_num,
                'goal': goal,
                'deadline': deadline,
                'completed': False,
                'created': datetime.datetime.now().isoformat()
            })
            goal_num += 1

        self.study_goals = goals

        print("\n" + "=" * 70)
        print("  YOUR STUDY GOALS")
        print("=" * 70)

        for i, goal in enumerate(goals, 1):
            status = "⬜" if not goal['completed'] else "✅"
            print(f"\n{i}. {status} {goal['goal']}")
            print(f"   📅 Deadline: {goal['deadline']}")

        print("\n" + "=" * 70)
        print("  💡 AI MOTIVATION:")
        print("  'A goal without a plan is just a wish.'")
        print("  Break each goal into small daily actions!")
        print("=" * 70)

        self.study_history.append({
            'type': 'goals',
            'timestamp': datetime.datetime.now().isoformat(),
            'goals': goals
        })

    def view_progress(self):
        """View study progress and history"""
        print("\n" + "=" * 70)
        print("  📊 YOUR STUDY PROGRESS & HISTORY")
        print("=" * 70)

        if not self.study_history:
            print("\nNo study history yet. Start using the assistant to track progress!")
            return

        print(f"\nTotal Sessions: {len(self.study_history)}")
        print("-" * 70)

        for i, session in enumerate(self.study_history[-5:], 1):  # Show last 5
            print(f"\n{i}. {session['type'].upper()} - {session['timestamp'][:10]}")
            if session['type'] == 'schedule':
                print("   Generated a study schedule")
            elif session['type'] == 'todo_list':
                print(f"   Created to-do list with {len(session['tasks'])} tasks")
            elif session['type'] == 'goals':
                print(f"   Set {len(session['goals'])} study goals")

        # Statistics
        total_sessions = len(self.study_history)
        schedules = sum(1 for s in self.study_history if s['type'] == 'schedule')
        todo_lists = sum(1 for s in self.study_history if s['type'] == 'todo_list')
        goals = sum(1 for s in self.study_history if s['type'] == 'goals')

        print("\n" + "=" * 70)
        print("  PROGRESS STATISTICS")
        print("=" * 70)
        print(f"\n  📅 Schedules Created: {schedules}")
        print(f"  ✅ To-Do Lists Made: {todo_lists}")
        print(f"  🎯 Goals Set: {goals}")
        print(f"\n  💡 AI INSIGHT: You're on track! Keep building momentum!")
        print("=" * 70)

    def ai_quiz(self):
        """AI-powered study quiz"""
        print("\n" + "=" * 70)
        print("  🧠 AI STUDY QUIZ")
        print("=" * 70)

        questions = [
            {
                'question': "What is the Pomodoro Technique?",
                'options': ["A) Study for 8 hours straight", 
                           "B) 25 min study + 5 min break cycles",
                           "C) Study only in the morning",
                           "D) Take no breaks"],
                'answer': 'B'
            },
            {
                'question': "What does 'active recall' mean?",
                'options': ["A) Re-reading notes multiple times",
                           "B) Highlighting important text",
                           "C) Testing yourself to retrieve information",
                           "D) Watching videos passively"],
                'answer': 'C'
            },
            {
                'question': "When is the best time to review notes?",
                'options': ["A) One week after class",
                           "B) Within 24 hours of class",
                           "C) Only before exams",
                           "D) Never, just attend class"],
                'answer': 'B'
            },
            {
                'question': "What is spaced repetition?",
                'options': ["A) Studying everything in one day",
                           "B) Reviewing at increasing time intervals",
                           "C) Only studying difficult topics",
                           "D) Skipping easy topics"],
                'answer': 'B'
            },
            {
                'question': "How many hours of sleep is optimal for memory?",
                'options': ["A) 4-5 hours",
                           "B) 6 hours",
                           "C) 7-8 hours",
                           "D) 10+ hours"],
                'answer': 'C'
            }
        ]

        score = 0

        for i, q in enumerate(questions, 1):
            print(f"\nQuestion {i}: {q['question']}")
            for option in q['options']:
                print(f"  {option}")

            answer = input("\nYour answer (A/B/C/D): ").strip().upper()

            if answer == q['answer']:
                print("✅ Correct! Well done!")
                score += 1
            else:
                print(f"❌ Incorrect. The correct answer is {q['answer']}")

        print("\n" + "=" * 70)
        print(f"  QUIZ COMPLETE!")
        print("=" * 70)
        print(f"\n  Your Score: {score}/{len(questions)} ({score/len(questions)*100:.0f}%)")

        if score == len(questions):
            print("  🏆 Perfect score! You're a study expert!")
        elif score >= len(questions) * 0.6:
            print("  👍 Good job! You know your study techniques!")
        else:
            print("  📚 Keep learning! Review the study tips and try again!")

        print("=" * 70)

    def chat_with_ai(self):
        """Simple AI chatbot"""
        print("\n" + "=" * 70)
        print("  💬 CHAT WITH AI ASSISTANT")
        print("=" * 70)

        print("\nAsk me anything about studying! (type 'quit' to exit)")
        print("-" * 70)

        responses = {
            'hello': "Hello! How can I help you study better today?",
            'hi': "Hi there! Ready to boost your productivity?",
            'help': "I can help you with: study schedules, to-do lists, study tips, subject recommendations, and goal setting!",
            'tired': "Feeling tired? Take a 15-minute power nap or go for a short walk. Fresh air works wonders!",
            'stressed': "Stressed? Take deep breaths. Break your work into smaller tasks. You've got this!",
            'motivate': "Remember: Every expert was once a beginner. Keep going, you're improving every day!",
            'procrastinate': "Beat procrastination: Start with just 5 minutes. Often, starting is the hardest part!",
            'focus': "Improve focus: Remove phone, use website blockers, try Pomodoro technique!",
            'memory': "Boost memory: Use active recall, spaced repetition, and get enough sleep!",
            'thanks': "You're welcome! Happy studying! 📚",
            'bye': "Goodbye! Come back anytime for study help! Good luck! 🚀"
        }

        while True:
            user_input = input("\nYou: ").strip().lower()

            if user_input == 'quit':
                print("\nAI: Goodbye! Happy studying! 📚")
                break

            # Find best response
            response = "I'm not sure about that, but try using the study tips feature for proven techniques!"

            for keyword, answer in responses.items():
                if keyword in user_input:
                    response = answer
                    break

            print(f"AI: {response}")

    def save_session(self):
        """Save session data"""
        print("\n" + "=" * 70)
        print("  📝 SAVING YOUR SESSION")
        print("=" * 70)

        session_data = {
            'user_name': self.user_name,
            'study_goals': self.study_goals,
            'tasks': self.tasks,
            'study_history': self.study_history,
            'timestamp': datetime.datetime.now().isoformat()
        }

        filename = f"study_session_{self.user_name.replace(' ', '_')}_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.json"

        try:
            with open(filename, 'w') as f:
                json.dump(session_data, f, indent=2)

            print(f"\n✓ Session saved to: {filename}")
            print("\nYour progress is saved! Load it next time to continue.")

        except Exception as e:
            print(f"\nError saving session: {e}")

    def run(self):
        """Main application loop"""
        self.greet_user()

        while True:
            self.display_menu()

            try:
                choice = int(input("\nEnter your choice (1-9): "))

                if choice == 1:
                    self.generate_study_schedule()
                elif choice == 2:
                    self.create_todo_list()
                elif choice == 3:
                    self.get_study_tips()
                elif choice == 4:
                    self.get_subject_recommendations()
                elif choice == 5:
                    self.set_study_goals()
                elif choice == 6:
                    self.view_progress()
                elif choice == 7:
                    self.ai_quiz()
                elif choice == 8:
                    self.chat_with_ai()
                elif choice == 9:
                    self.save_session()
                    print("\n" + "=" * 70)
                    print("  Thank you for using AI Study Assistant!")
                    print("  Come back soon for more study help! 🚀")
                    print("=" * 70)
                    break
                else:
                    print("\nInvalid choice! Please enter 1-9.")

            except ValueError:
                print("\nInvalid input! Please enter a number.")
            except KeyboardInterrupt:
                print("\n\nSession interrupted. Goodbye! 👋")
                break

# Main entry point
if __name__ == "__main__":
    assistant = AIStudyAssistant()
    assistant.run()
