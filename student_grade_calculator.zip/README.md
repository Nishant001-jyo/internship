# Student Grade Calculator

A simple Python project to calculate student grades based on marks.

## Features

- Input marks for multiple subjects
- Calculate total, average, and percentage
- Assign letter grades based on percentage (A+, A, B+, B, C, D, F)
- Display comprehensive grade report
- Process multiple students

## Grade Scale

| Percentage | Grade | Status |
|------------|-------|--------|
| 90-100     | A+    | PASS   |
| 80-89      | A     | PASS   |
| 70-79      | B+    | PASS   |
| 60-69      | B     | PASS   |
| 50-59      | C     | PASS   |
| 40-49      | D     | PASS   |
| 0-39       | F     | FAIL   |

## How to Run

1. Make sure you have Python 3 installed
2. Open terminal/command prompt
3. Navigate to the project directory
4. Run: `python grade_calculator.py`
5. Follow the prompts to enter student information and marks

## Example Usage

```
==================================================
       STUDENT GRADE CALCULATOR
==================================================

Enter student name: John Doe
Enter roll number: CS2024001

Enter number of subjects: 5

Enter marks for 5 subjects (out of 100):
--------------------------------------------------
Subject 1 name: Mathematics
Enter marks for Mathematics: 85
Subject 2 name: Physics
Enter marks for Physics: 78
...

==================================================
              GRADE REPORT
==================================================

Student Name: John Doe
Roll Number: CS2024001
Number of Subjects: 5

--------------------------------------------------
Subject-wise Marks:
--------------------------------------------------
Subject                         Marks
--------------------------------------------------
Mathematics                      85.00
Physics                          78.00
...
--------------------------------------------------
TOTAL                           412.00
--------------------------------------------------

Average Marks: 82.40
Percentage: 82.40%
Grade: A
Status: PASS
==================================================
```

## Project Structure

```
student_grade_calculator/
│
├── grade_calculator.py    # Main Python script
├── README.md              # This file
└── requirements.txt       # Dependencies (if any)
```

## Concepts Demonstrated

- Functions and modular programming
- Input validation and error handling
- Conditional statements (if-elif-else)
- Loops (for and while)
- Lists and data structures
- String formatting
- Dictionary data structures

## Author

Created as a Python mini project for learning purposes.

## License

Free to use for educational purposes.
