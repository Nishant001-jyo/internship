"""
Student Grade Calculator
A simple Python project to calculate student grades based on marks.
Features:
- Input marks for multiple subjects
- Calculate total, average, and percentage
- Assign letter grades based on percentage
- Display grade report
"""

def calculate_grade(percentage):
    """
    Assign letter grade based on percentage.
    """
    if percentage >= 90:
        return 'A+'
    elif percentage >= 80:
        return 'A'
    elif percentage >= 70:
        return 'B+'
    elif percentage >= 60:
        return 'B'
    elif percentage >= 50:
        return 'C'
    elif percentage >= 40:
        return 'D'
    else:
        return 'F'

def get_status(grade):
    """
    Determine pass/fail status based on grade.
    """
    if grade == 'F':
        return 'FAIL'
    else:
        return 'PASS'

def calculate_student_grade():
    """
    Main function to calculate and display student grades.
    """
    print("=" * 50)
    print("       STUDENT GRADE CALCULATOR")
    print("=" * 50)

    # Get student information
    student_name = input("
Enter student name: ").strip()
    roll_number = input("Enter roll number: ").strip()

    # Get number of subjects
    while True:
        try:
            num_subjects = int(input("
Enter number of subjects: "))
            if num_subjects > 0:
                break
            else:
                print("Please enter a positive number!")
        except ValueError:
            print("Invalid input! Please enter a number.")

    # Get marks for each subject
    subjects = []
    marks = []
    total_marks = 0
    max_marks_per_subject = 100

    print(f"
Enter marks for {num_subjects} subjects (out of 100):")
    print("-" * 50)

    for i in range(num_subjects):
        while True:
            try:
                subject_name = input(f"Subject {i+1} name: ").strip()
                mark = float(input(f"Enter marks for {subject_name}: "))

                if 0 <= mark <= max_marks_per_subject:
                    subjects.append(subject_name)
                    marks.append(mark)
                    total_marks += mark
                    break
                else:
                    print(f"Marks must be between 0 and {max_marks_per_subject}!")
            except ValueError:
                print("Invalid input! Please enter a number.")

    # Calculate results
    average_marks = total_marks / num_subjects
    percentage = (total_marks / (num_subjects * max_marks_per_subject)) * 100
    grade = calculate_grade(percentage)
    status = get_status(grade)

    # Display grade report
    print("
" + "=" * 50)
    print("              GRADE REPORT")
    print("=" * 50)
    print(f"
Student Name: {student_name}")
    print(f"Roll Number: {roll_number}")
    print(f"Number of Subjects: {num_subjects}")

    print("
" + "-" * 50)
    print("Subject-wise Marks:")
    print("-" * 50)
    print(f"{'Subject':<25} {'Marks':>15}")
    print("-" * 50)

    for i in range(len(subjects)):
        print(f"{subjects[i]:<25} {marks[i]:>15.2f}")

    print("-" * 50)
    print(f"{'TOTAL':<25} {total_marks:>15.2f}")
    print("-" * 50)

    print(f"
Average Marks: {average_marks:.2f}")
    print(f"Percentage: {percentage:.2f}%")
    print(f"Grade: {grade}")
    print(f"Status: {status}")
    print("=" * 50)

    return {
        'name': student_name,
        'roll_number': roll_number,
        'subjects': subjects,
        'marks': marks,
        'total': total_marks,
        'average': average_marks,
        'percentage': percentage,
        'grade': grade,
        'status': status
    }

def main():
    """
    Main entry point of the program.
    """
    while True:
        result = calculate_student_grade()

        choice = input("
Do you want to calculate another student's grade? (yes/no): ").strip().lower()
        if choice not in ['yes', 'y']:
            print("
Thank you for using Student Grade Calculator!")
            print("Goodbye!")
            break
        print("
" + "=" * 50)

if __name__ == "__main__":
    main()
